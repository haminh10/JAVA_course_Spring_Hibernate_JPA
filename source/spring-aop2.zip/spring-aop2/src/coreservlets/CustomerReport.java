package coreservlets;

public interface CustomerReport {

  public String getReport(String customerName);
  
}

package coreservlets.persistence;

import javax.sql.DataSource;

import org.springframework.jdbc.core.simple.SimpleJdbcTemplate;

import coreservlets.Customer;

public class SpringJdbcCustomerBatchPersistence implements CustomerBatchPersistence {

  private SimpleJdbcTemplate simpleJdbc;

  public SpringJdbcCustomerBatchPersistence(DataSource dataSource) {
    this.simpleJdbc = new SimpleJdbcTemplate(dataSource);
  }
  
  public int getCustomerCount(){
    return simpleJdbc.queryForInt("select count(*) from customer");
  }

  public void insert(Customer...customers) {
    if(customers == null){
      return;
    }
    for(Customer customer : customers){
      simpleJdbc.update(
        "insert into customer (id, name)"
        + " values (?, ?)",
        customer.getId(),
        customer.getName());
    }
  }
}
